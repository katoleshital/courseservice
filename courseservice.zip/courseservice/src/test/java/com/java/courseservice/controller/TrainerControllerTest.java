package com.java.courseservice.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.java.courseservice.dto.CourseRequestDto;
import com.java.courseservice.entity.Course;
import com.java.courseservice.service.TrainerService;

@SpringBootTest
public class TrainerControllerTest {

	@Mock
	TrainerService trainerService;

	@InjectMocks
	TrainerController trainerController;

	CourseRequestDto courseRequestDto;

	Course course;

	@BeforeEach
	public void setUp() {
		courseRequestDto = new CourseRequestDto();
		courseRequestDto.setCourseName("java");
		courseRequestDto.setPrice(3400d);

		course = new Course();
		course.setCourseId(1);
		course.setCourseName("java");
		course.setPrice(3400d);
		course.setUserId(1);
	}

	@Test
	@DisplayName("addCourseTest:Positive")
	public void addCourseTest_Positive() {
		// context
		when(trainerService.addCourse(courseRequestDto, 1)).thenReturn("Course created successfully");
		// event
		ResponseEntity<String> result = trainerController.addCourse(courseRequestDto, 1);

		assertEquals("Course created successfully", result.getBody());
		assertEquals(HttpStatus.CREATED, result.getStatusCode());

	}

	@Test
	@DisplayName("addCourseTest:Negative")
	public void addCourseTest_Negative() {
		// context
		when(trainerService.addCourse(courseRequestDto, 1)).thenReturn("Course creation was unsuccessfull");
		// event
		ResponseEntity<String> result = trainerController.addCourse(courseRequestDto, 1);

		assertEquals("Course creation was unsuccessfull", result.getBody());
		assertEquals(HttpStatus.CREATED, result.getStatusCode());

	}

}
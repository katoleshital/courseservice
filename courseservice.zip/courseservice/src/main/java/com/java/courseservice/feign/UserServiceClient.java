package com.java.courseservice.feign;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.courseservice.dto.CourseRequestDto;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@FeignClient(name = "userservice")
public interface UserServiceClient {

	// @CircuitBreaker(name = "usercircuitbreaker", fallbackMethod =
	// "userFallBackMethod")
	@GetMapping("/users/userId")
	public String getRoleByUserId(@Valid @RequestParam Integer userId);

	public default String userFallBackMethod(Exception ex) {
		return "user service is down wait for some time";
	}

}

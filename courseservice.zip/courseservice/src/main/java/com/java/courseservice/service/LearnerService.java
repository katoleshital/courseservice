package com.java.courseservice.service;

import java.util.List;

import com.java.courseservice.dto.CourseResponseDto;
import com.java.courseservice.entity.Course;
import com.java.courseservice.exception.CourseNotFoundException;

public interface LearnerService {

	List<CourseResponseDto> viewCourses();

	CourseResponseDto searchCourseByCourseName(String courseName) throws CourseNotFoundException;

	CourseResponseDto viewCourseByCourseId(Integer courseId) throws CourseNotFoundException;

}
